# 💸 BNB&BEP20 转账监控 Discord 机器人

本项目是一个基于 TypeScript 的高性能监控服务，旨在跨多个 EVM 链进行实时交易监听。**它特别支持同时监控币安智能链 (BSC) 和 opBNB 网络。**

它使用 Ethers.js 来监听两种关键的交易类型：**原生代币转账（例如，BSC/opBNB 上的 BNB）**和通过合约事件发出的 **ERC20/BEP20 代币转账**。警报会即时发送到配置好的 Discord 频道，并且所有已处理的交易都会记录到本地 CSV 文件中。

## 快速开始 (Getting Started)

请按照以下说明设置并运行您的本地监控机器人。

### 前提条件 (Prerequisites)

您需要安装以下软件：

* **Node.js**：版本 18 或更高（推荐使用 LTS）。
* **npm 或 Yarn**：Node.js 包管理器。
* **稳定的 WebSocket RPC URL**：拥有您希望监控的网络（BSC 和 opBNB）的稳定、私有 WebSocket 端点。公共端点通常不可靠，不适合持续监控。
* **Discord 机器人 Token**：您的 Discord 应用机器人的 Token。
* **Discord 频道 ID**：用于发送警报的特定频道 ID。

### 安装步骤 (Installation)

1.  **克隆代码库：**
    ```bash
    git clone [https://github.com/your-username/discord-bot.git](https://github.com/your-username/discord-bot.git)
    cd discord-bot
    ```

2.  **安装依赖：**
    ```bash
    npm install
    # 或
    yarn install
    ```

3.  **项目配置：**
    使用您的环境信息更新 `config.ts` 中的设置：

    * **Discord 凭证**：设置 `discord.bot_token` 和 `discord.channel_id`，需要文本类型的频道。
    * **RPC 端点**：设置 `bsc.rpc_wss_url` 和 `opbnb.rpc_wss_url`，需要websocket类型的端点，支持infura。
    * **监控过滤器**：定义监控规则，这些规则可独立应用于不同的网络和交易类型：
        * **原生代币 (BNB)**：配置 `bsc.bnb` 和 `opbnb.bnb`，通过地址 (`froms`, `tos`) 或最小金额 (`min_value`) 过滤 BNB 转账。
        * **代币 (BEP20)**：配置 `bsc.contracts` 和 `opbnb.contracts`，包含代币地址和相应的过滤器，用于 BEP20 `Transfer` 事件。

### 运行项目 (Running the Project)

使用以下命令运行应用程序：

```bash
npm start
# 或
yarn start
