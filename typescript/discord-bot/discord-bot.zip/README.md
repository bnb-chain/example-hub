# 💸 Web3 Transfer Monitor Discord Bot

This project is a high-performance, TypeScript-based monitoring service designed for simultaneous real-time transaction listening across multiple EVM chains. **It specifically supports monitoring both the Binance Smart Chain (BSC) and opBNB networks.**

It utilizes Ethers.js to listen to two critical transaction types: **Native Coin transfers (e.g., BNB on BSC/opBNB)** and **ERC20/BEP20 token transfers** via contract events. Alerts are sent to a configured Discord channel instantly, and all processed transactions are logged to local CSV files.

## Getting Started

Follow these instructions to set up and run the monitoring bot on your local machine.

### Prerequisites

You need the following software installed:

* **Node.js**: Version 18 or higher (LTS recommended).
* **npm** or **Yarn**: Node.js package manager.
* **Stable WebSocket RPC URLs**: Access to reliable, private **WebSocket (WSS)** endpoints for **BSC** and **opBNB**. This service supports endpoints from major providers such as [Infura](https://infura.io/), [Alchemy](https://www.alchemy.com/), and [QuickNode](https://www.quicknode.com/).
* **A Discord Bot Token**: A token for a Discord application bot.
* **A Discord Channel ID**: The specific text channel where alerts will be sent.

### Installation

1.  **Clone the repository:**
    ```bash
    git clone [https://github.com/your-username/discord-bot.git](https://github.com/your-username/discord-bot.git)
    cd discord-bot
    ```

2.  **Install dependencies:**
    ```bash
    npm install
    # or
    yarn install
    ```

3.  **Configure the project:**
    Update the settings in `config.ts` with your environment details:

    * **Discord Setup**:
        * Set `discord.bot_token` and `discord.channel_id`.
        * **Important**: The target Discord channel must be a **Text Channel**. The bot requires the **Embed Links** and **Send Messages** permissions within that channel to post alerts correctly.
        * **Bot Registration**: For guidance on setting up and registering your Discord bot application, please refer to the official documentation: [Discord.js Bot Setup Guide](https://discordjs.guide/legacy/preparations/app-setup).
    * **RPC Endpoints**: Set `bsc.rpc_wss_url` and `opbnb.rpc_wss_url` to your **WebSocket (WSS)** endpoints.
    * **Monitoring Filters**: Define monitoring rules, which can be applied independently to both networks and transaction types:
        * **Native Coin (BNB)**: Configure `bsc.bnb` and `opbnb.bnb` to filter BNB transfers by addresses (`froms`, `tos`) or minimum value (`min_value`).
        * **Token (BEP20)**: Configure `bsc.contracts` and `opbnb.contracts` with token addresses and associated filters for specific BEP20 Transfer events.

### Running the Project

Run the application using the following command:

```bash
npm start
# or
yarn start
